#include "server.h"
using namespace std;
int main() {
    Server server;
    server.run();
    return 0;
}
